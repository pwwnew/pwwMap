/******************************************************************************
Title:       The core of the big data solutions -- Map
Author:      pengwenwei
Email:       pww71@foxmail.com
Language:    c++
Platform:    Windows, linux
Technology:  Perfect hash algorithm
Level:       Advanced
Description: Enter a brief description of your article
Section      MFC c++ map stl
SubSection   c++ algorithm
License:     (GPLv3)

This file is part of pwwHashMap.
 
pwwHashMap is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
 
pwwHashMap is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
 
You should have received a copy of the GNU General Public License
along with pwwHashMap.  If not, see <http://www.gnu.org/licenses/>.

******************************************************************************/

#ifndef _PWWDISKMAP_H
#define _PWWDISKMAP_H
#include "PwwHash.h"

#ifdef WIN32
#include <direct.h> //use _chdir() and _getcwd() function
#include <io.h> //use _findfirst() and findnext() function
#else
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#endif

#ifdef WIN32
#define pww_fseeki64 _fseeki64
#define pww_ftelli64 _ftelli64
#define pww_getcwd _getcwd
#define pww_access(a,b) _access(a,b)
#define pww_mkdir(a) _mkdir(a)
#define pww_rmdir _rmdir
#define pww_unlink _unlink
#define pww_itoa(p,kpos) itoa(kpos,p,10)
#define pww_DirSpilt '\\'
#define pww_LocalDir   "\\pww"
#else
#define pww_DirSpilt '/'
#define pww_LocalDir  "/pww"
#define pww_fseeki64 fseeko64
#define pww_ftelli64 ftello64
#define pww_getcwd getcwd
#define pww_access(a,b) access(a,b)
#define pww_mkdir(a) mkdir(a,S_IRUSR|S_IWUSR|S_IXUSR)
#define pww_rmdir rmdir
#define pww_unlink unlink
#define pww_itoa(p,kpos) sprintf(p,"%d",kpos)
#endif

#define DATAFILEEXT		".dat"
#define DATADEL			".del"

#define FiveByte
#ifdef FiveByte
#define Len_Short64 5
#define Max_Short64 0xFFFFFFFFFF	
#else
#define Len_Short64 6
#define Max_Short64 0xFFFFFFFFFFFF	
#endif

//#define Big_Endian
#ifdef Big_Endian
const unsigned char movePos = ((sizeof(pww__uint64) - Len_Short64) << 3);
#define Buf_Short64(p) (p+sizeof(pww__uint64)-Len_Short64)
#define Write_Short64(p,fp)	fwrite((unsigned char*)p+sizeof(pww__uint64)-Len_Short64, Len_Short64, 1, fp)
#define Read_Short64(r,fp) fread(&r, Len_Short64, 1, fp);	\
	(r >>= (movePos))
//#define Short64ToUint64(r) (r >>= (movePos))
#define Short64ToUint64(p,s)		p=0;	\
	memcpy(&(p)+sizeof(pww__uint64) - Len_Short64,s,Len_Short64)

#else
#define Buf_Short64(p) (p)
#define Write_Short64(p,fp)	fwrite(p, Len_Short64, 1, fp)
#define Read_Short64(r,fp) fread(&r, Len_Short64, 1, fp);	\
	(r &= (Max_Short64))
//#define Short64ToUint64(r) (r &= (Max_Short64))
#define Short64ToUint64(p,s)		p=0;	\
		memcpy(&p,s,Len_Short64)

#endif
/*
#define GetBit(dat,i) (dat&((pww__uint64)1<<i))				
#define SetBit(dat,i) ((dat)|=((pww__uint64)1<<(i)))		
#define ClearBit(dat,i) ((dat)&=(~((pww__uint64)1<<(i))))	
#define BitGet(dat,i) ((dat) ^= (pww__uint64)1<<(i))			
*/

const unsigned int RWBUF = 1024000; //diskmap read and write cache, used to adjust the performance
const unsigned short BLOCKMEMLEN = 8192;
const unsigned short g_pLen = sizeof(unsigned short) + Len_Short64;
const unsigned short g_ppLen = g_pLen+Len_Short64;
const unsigned short g_pppLen = g_ppLen + sizeof(unsigned short);

class PWWHASH_EXPORTS CPwwDiskMap :public CPwwHash
{
public:
	struct PWWHASH_EXPORTS S_PwwFile
	{
		struct S_RBUFBLOCK
		{
			pww__int64 filePos;
			pww__int64 RPos;
		}* RBufBlock;

		S_PwwFile(){};
		S_PwwFile(char* filename,int bN=1,int wBufLen=RWBUF);

		~S_PwwFile();

		void reSet();
		void checkRBufBlock(pww__int64& readFileLen);
		void checkRbuf(unsigned int  len);
		void openPwwRead();
		void closePwwRead();
		bool pwwRead1(unsigned char *& ptr, unsigned int len, pww__int64 pos);
		bool pwwRead2(unsigned char *& ptr, unsigned int len, pww__int64 pos);

		void pwwWrite(void * ptr, unsigned int  len);
		void pwwFflush();
		bool checkPos();
		void checkWbuf(unsigned int  len);
		void rebuildIni();
		void rebuildOver(int bN);
		
		pww__int64 fileSize;
		unsigned char* WBuf;
		unsigned int WPos;
		unsigned int WBufLen;
		FILE* fpR;
		char* fileName;

		unsigned char* RBuf;
		unsigned int blockNum; 
		unsigned int blockBufLen;
		pww__int64 RBufLen;

		pww__int64 fileBlock; 
		pww__int64 curPos;

	};

	struct S_pppklParam
	{
		S_pppklParam()
		{
			memset(this,0,sizeof(*this));
		};
		~S_pppklParam()
		{

		};

		pww__uint64 nPos;
		pww__uint64 lPos;
		unsigned short vL;
		unsigned short kpos;

		unsigned char* ucKey;
		unsigned char* ucValue;
	};

public:
	CPwwDiskMap(int iKeyLen,S_PwwFile& fpDat,S_PwwFile& fpDel,CPwwHash& mpDel);
	virtual ~CPwwDiskMap();

	//Based on the hard disk No memory consumption
	virtual bool diskMapInsert(unsigned char* ucKey,  unsigned char* ucValue = 0, unsigned short usValueLen = 0);
	virtual bool diskMapFind(unsigned char* ucKey,  unsigned char*& ucValue);
	virtual bool diskMapModify(unsigned char* ucKey,  unsigned char*& ucValue, unsigned short usValueLen);
	virtual bool diskMapDel(unsigned char* ucKey);
	virtual void delHashMapMem();
	virtual void analyIni();
	void setDiskMapKeyLen(unsigned short len)
	{
		m_diskKeyLen = len;
		m_iLPPpKlLen = sizeof(unsigned short)+(Len_Short64<<1)+(sizeof(unsigned short)<<1)+m_diskKeyLen;
	};
	
	static void pwwDiskMapIni(char* path,char*pathbk,bool preFixHash=true);
	static void pwwDiskMapRelease();
	static 	void mkMapDir(char* mapPath);
	static void getPwwDiskPath(char* pchPath,int sign);
	static unsigned int getHashPrefix(unsigned char *key,unsigned short len);
	static bool insertSign(int& mapSign,unsigned char* p);
	static void delSign(int& mapSign);
	static char* g_diskMapPath[2];
	static CPwwHash g_mpSign;
	static unsigned int cryptTable[0x500];
private:
	int getPos( S_pppklParam& pppklPa);
	static void initCryptTable();
private:
	
	CPwwHash& m_mpDel;
	S_PwwFile& m_fpDat;
	S_PwwFile& m_fpDel;
	unsigned short m_diskKeyLen;
	int m_iLPPpKlLen;

};
#endif
